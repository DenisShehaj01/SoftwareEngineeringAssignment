// |Client side script to construct/display the parking grids  

// And If time/cba make the server send an array of availabilities instead of doing individual requests////

async function GetAvailability(CarParkId, spaceId) { //Function to fetch the availibility of a space from the server
  try {
      const lastCharOfCarParkId = CarParkId.slice(-1); // Gets the last character of the CarParkId
      const response = await fetch(`/carparkgui/space-availability/${lastCharOfCarParkId}/${spaceId}`);
      const data = await response.json();
      console.log(data.status);
      return data.status;
  } catch (error) {
      console.error('Error fetching space statsus:', error);
      return 'blocked'; // Default to blocked if there's an error
  }
}

document.addEventListener('DOMContentLoaded', async function() {
    const state = loadState() || {};
    function initializeCarPark(CarParkId, spaces) {
      const CarPark = document.getElementById(CarParkId);
      if (!CarPark){
      console.error("Parking lot element not found:", CarParkId);
      return;
      }
      let row, space, label, statusDisplay, rowCount = 4;  // Assuming 4 spaces per row for layout
      for (let i = 0; i < Math.ceil(spaces / rowCount); i++) {
        row = document.createElement('div');
        row.className = 'row';
        for (let j = 0; j < rowCount; j++) {
            space = document.createElement('div');
            space.className = 'space';
            space.id = `${CarParkId}_space${i * rowCount + j}`;
            label = document.createElement('div');
            label.className = 'label';
            label.innerText = String.fromCharCode(65 + i) + (j + 1);
            console.log(label.innerText);
            space.appendChild(label);
            statusDisplay = document.createElement('div');
            statusDisplay.className = 'status-display';
            addStatusToDisplay(statusDisplay, space.id);
            space.appendChild(statusDisplay);
            row.appendChild(space);
        }
        CarPark.appendChild(row);
        console.log("Added row to", CarParkId);
      }
   } 

    function addStatusToDisplay(statusDisplay, spaceId) {
        const time = document.getElementById('timeSelector').value;
        const savedStatus = state[spaceId] && state[spaceId][time];
        const statusText = savedStatus ? savedStatus : 'blocked'; // Default to 'available' if no status
        statusDisplay.innerText = statusText;
        statusDisplay.style.backgroundColor = getStatusColor(statusText);
        statusDisplay.style.padding = '5px'; // Add padding for better visibility
        statusDisplay.style.borderRadius = '4px'; // Optional: for better aesthetics
    }


    function getStatusColor(status) {
      switch (status) {
        case 'available': return 'limegreen';
        case 'reserved': return 'orange';
        case 'blocked': return 'red';
        default: return 'transparent';
      }
    }

    async function loadStateForTime(time) {
      document.querySelectorAll('.space').forEach(async space => {
      const statusDisplay = space.querySelector('.status-display');
      const [lotId, spaceId] = space.id.split('_space');
      //const status = state[lotId] && state[lotId][spaceId] && state[lotId][spaceId][time] ? state[lotId][spaceId][time] : 'available';
      const status = await GetAvailability(lotId, spaceId);
      console.log(status);
      statusDisplay.innerText = status;
      statusDisplay.style.backgroundColor = getStatusColor(status);
      

    })};


    function loadState() {
      return JSON.parse(localStorage.getItem('parkingState'));
    }

    function saveState() {
      localStorage.setItem('parkingState', JSON.stringify(state));
    }

    document.getElementById('timeSelector').addEventListener('change', function() {
      loadStateForTime(this.value);
    });

    // Initialize parking lots
    initializeCarPark('CarPark1', 20);
    initializeCarPark('CarPark2', 20);
    initializeCarPark('CarPark3', 20);
    loadStateForTime(document.getElementById('timeSelector').value);
  });