const mysql = require('mysql');
const express = require('express')
const app = express();

app .get("/",(req, res) => {
res.send("<h1> Testing </h>")
})

//Create a connection to the database
const connection = mysql.createConnection({
 host: 'localhost', 
 user: 'root', 
 password: 'admin', 
 database: 'CarParks' 
});

// Connect to the database
connection.connect(function(err) {
if (err)  throw err;
   console.error('Error connecting to MySQL database:', err);
console.log('Connected to MySQL database');
});

module.exports = connection;